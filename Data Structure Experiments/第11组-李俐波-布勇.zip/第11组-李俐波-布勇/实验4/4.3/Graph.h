#pragma once
#include <iostream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <string>
#include <algorithm>
/*
 *ͼ�ı�ʾ��ʽ G=(V,E) V�Ƕ��� E�Ǳ�
 *
 */
using namespace std;
template <class V, class W, bool Direction = false> // DirectionΪ�Ƿ�����
class Graph_Matrix
{
    typedef Graph_Matrix<V, W, Direction> Self;

public:
    Graph_Matrix(const V* vertex, size_t n) // ��ʼ������
    {
        // _vertex.reserve(n);
        for (int i = 0; i < n; i++)
        {
            _vertex.push_back(vertex[i]);
            _vIndex[vertex[i]] = i;
        }
        // ��ʼ���ڽӾ���
        _matrix.resize(n);
        for (auto& e : _matrix)
        {
            e.resize(n, INT_MAX);
        }
        for (int i = 0; i < n; i++)
        {
            _matrix[i][i] = 0;
        }
    }
    // ���ڽӾ����ʼ��
    Graph_Matrix(const std::vector<std::vector<W>>& m)
    {
        for (int i = 0; i < m.size(); i++)
        {
            for (int j = 0; j < m[0].size(); j++)
            {
                _matrix[i][j] = m[i][j];
            }
        }
    }
    int getVertexIndex(const V& v)
    {
        auto ret = _vIndex.find(v);
        if (ret != _vIndex.end())
        {
            return ret->second;
        }
        else
        {
            std::cerr << "error, don't have this vertex\n";
            return -1;
        }
    }
    void addEdge(const V& src, const V& dst, const W& w)
    {
        int srci = getVertexIndex(src);
        int dsti = getVertexIndex(dst);
        _matrix[srci][dsti] = w;
        if (Direction == false)
        {
            _matrix[dsti][srci] = w;
        }
    }

    void Print()
    {
        // ��ӡ������±�ӳ���ϵ
        std::cout << "������±�ӳ���ϵ: ";
        for (size_t i = 0; i < _vertex.size(); i++)
        {
            std::cout << _vertex[i] << "-" << i << " ";
        }
        std::cout << std::endl
            << std::endl;
        std::cout << "�ڽӾ���:\n";
        std::cout << "  ";
        for (size_t i = 0; i < _vertex.size(); ++i)
        {
            std::cout << i << " ";
        }
        std::cout << std::endl;
        // ��ӡ�ڽӾ���
        for (size_t i = 0; i < _matrix.size(); ++i)
        {
            std::cout << i << " ";
            for (size_t j = 0; j < _matrix[i].size(); ++j)
            {
                if (_matrix[i][j] != INT_MAX)
                    std::cout << _matrix[i][j] << " ";
                else
                    std::cout << "#" << " ";
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;
        // ��ӡ���еı�
        std::cout << "���бߵ����:\n";
        for (size_t i = 0; i < _matrix.size(); ++i)
        {
            for (size_t j = 0; j < _matrix[i].size(); ++j)
            {
                if (i != j && _matrix[i][j] != INT_MAX)
                {
                    std::cout << _vertex[i] << "-" << _vertex[j] << ":" << _matrix[i][j] << "  ";
                }
            }
            std::cout << std::endl;
        }
        // ��ӡÿ������Ķ�
        std::cout << "���ж���Ķ�:\n";
        if (Direction == false) // ����ͼ
        {
            for (int i = 0; i < _vertex.size(); i++)
            {
                int degree = 0;
                for (int j = 0; j < _vertex.size(); j++)
                {
                    if (_matrix[i][j] != INT_MAX && i != j)
                    {
                        degree++;
                    }
                }
                std::cout << "���� " << _vertex[i] << " �Ķ�Ϊ " << degree << std::endl;
            }
        }
        else // ����ͼ
        {
            for (int i = 0; i < _vertex.size(); i++)
            {
                int in_degree = 0;
                int out_degree = 0;
                for (int j = 0; j < _vertex.size(); j++)
                {
                    if (_matrix[j][i] != INT_MAX && j != i)
                    {
                        in_degree++;
                    }
                    if (_matrix[i][j] != INT_MAX && i != j)
                    {
                        out_degree++;
                    }
                }
                std::cout << "���� " << _vertex[i] << " �����Ϊ " << in_degree << "������Ϊ " << out_degree << std::endl;
            }
        }
        std::cout << std::endl;
    }
    void BFS(const V& src) // ����һ����ʼBFS
    {
        int srci = getVertexIndex(src);
        std::vector<bool> visited(_vertex.size(), false);
        std::queue<int> q;
        std::cout << "The graph from point " << _vertex[srci] << "'s BFS: " << std::endl;
        q.push(srci);
        visited[srci] = true;
        std::cout << srci << src << " ";
        while (!q.empty())
        {
            int font = q.front();
            q.pop();
            for (int i = 0; i < _vertex.size(); i++)
            {
                if (_matrix[font][i] != INT_MAX && visited[i] == false)
                {
                    visited[i] = true;
                    std::cout << i << _vertex[i] << " ";
                    q.push(i);
                }
            }
            // std::cout << std::endl;
        }
        std::cout << std::endl
            << std::endl;
    }

    void DFS(const V& src)
    {
        int srci = getVertexIndex(src);
        std::cout << "The graph from point " << _vertex[srci] << "'s DFS: " << std::endl;
        std::vector<bool> visited(_vertex.size(), false);
        _DFS(srci, visited);
        std::cout << std::endl
            << std::endl;
    }

    void Prim(const V& src)
    {
        if (Direction)
        {
            std::cerr << "Prim's algorithm is not applicable to directed graphs." << std::endl;
            return;
        }
        int srci = getVertexIndex(src);
        std::vector<W> minWeight(_vertex.size(), INT_MAX);
        std::vector<int> parent(_vertex.size(), -1); // ��¼��С��������˫�׽ڵ�
        std::vector<bool> visited(_vertex.size(), false);
        minWeight[srci] = 0;
        // ʹ�����ȶ����Ż���greater�Ǳ�С��
        std::priority_queue<std::pair<W, int>, std::vector<std::pair<W, int>>, std::greater<std::pair<W, int>>> pq;
        pq.push({ minWeight[srci], srci });
        while (!pq.empty())
        {
            int u = pq.top().second;
            pq.pop();
            if (visited[u])
                continue;
            visited[u] = true;
            for (int i = 0; i < _vertex.size(); i++)
            {
                if (_matrix[u][i] != INT_MAX && !visited[i] && _matrix[u][i] < minWeight[i])
                {
                    minWeight[i] = _matrix[u][i]; // ����
                    parent[i] = u;
                    pq.push({ minWeight[i], i });
                }
            }
        }
        std::cout << "Prim's MST from " << src << ": " << "\n";
        for (int i = 0; i < _vertex.size(); i++)
        {
            if (parent[i] != -1)
            {
                std::cout << _vertex[parent[i]] << " - " << _vertex[i] << " : " << _matrix[parent[i]][i] << "\n";
            }
        }
        std::cout << std::endl;
    }
    W Dijkstra(const V& src, const V& dst)
    {
        int srci = getVertexIndex(src);
        int dsti = getVertexIndex(dst);
        std::vector<W> dist(_vertex.size(), INT_MAX);
        std::vector<int> parent(_vertex.size(), -1); // ��¼·��
        std::vector<bool> visited(_vertex.size(), false);
        dist[srci] = 0;

        // ʹ�����ȶ����Ż���greater�Ǳ�С��
        std::priority_queue<std::pair<W, int>, std::vector<std::pair<W, int>>, std::greater<std::pair<W, int>>> pq;
        pq.push({ dist[srci], srci });

        while (!pq.empty())
        {
            int u = pq.top().second;
            pq.pop();
            if (visited[u])
                continue;
            visited[u] = true;

            for (int i = 0; i < _vertex.size(); i++)
            {
                if (_matrix[u][i] != INT_MAX && !visited[i] && dist[u] + _matrix[u][i] < dist[i])
                {
                    dist[i] = dist[u] + _matrix[u][i];//��prime�㷨������
                    parent[i] = u;
                    pq.push({ dist[i], i });
                }
            }
        }

        // ��ӡ·��
        std::cout << "Dijkstra's shortest path from " << src << " to " << dst << ": ";
        if (dist[dsti] == INT_MAX)
        {
            std::cout << "No path found." << std::endl;
            return INT_MAX;
        }

        std::vector<int> path;
        for (int v = dsti; v != -1; v = parent[v])
        {
            path.push_back(v);
        }
        std::reverse(path.begin(), path.end());

        for (int i = 0; i < path.size(); ++i)
        {
            std::cout << _vertex[path[i]];
            if (i != path.size() - 1)
            {
                std::cout << " -> ";
            }
        }
        std::cout << std::endl;

        return dist[dsti];
    }
    W TravelAll(const V& src)
    {

        int N = _vertex.size(); // ��ȡͼ�нڵ������
        int src_index = getVertexIndex(src); // ��ȡ��ʼ�ڵ������

        // ����״̬�� (�ܾ���, ��ǰ�ڵ�����, �ѷ��ʽڵ��λ���롢1���ʣ�0δ����)��������ʽ
        typedef std::tuple<W, int, int> State;
        // typedef std::pair<W, pair<int, int>> A;
        // ��ʼ���������dist[node][mask] ��ʾ���� node���ѷ��ʽڵ㼯��Ϊ mask ����̾���
        std::vector<std::vector<W>> dist(N, std::vector<W>(1 << N, INT_MAX));

        // ��ʼ�����ڵ����parent[node][mask] �洢ǰ���ڵ��ǰ��״̬�������ؽ�·��
        std::vector<std::vector<std::pair<int, int>>> parent(N, std::vector<std::pair<int, int>>(1 << N, { -1, -1 }));

        // ��ʼ״̬������Ϊ 0����ǰ�ڵ�Ϊ src_index���ѷ��ʽڵ㼯��ֻ������ʼ�ڵ�
        dist[src_index][1 << src_index] = 0;

        // �������ȶ��У���С�ѣ��������ܾ����С��������
        std::priority_queue<State, std::vector<State>, std::greater<State>> pq;
        pq.push({ 0, src_index, 1 << src_index });

        // ��ʼ״̬�ռ�����
        while (!pq.empty())
        {
            // ȡ��������С��״̬
            auto [total_distance, current_node, visited_nodes_bitmask] = pq.top();
            //int u = std::get<1>(pq.top());
            pq.pop();

            // �����״̬�ľ����Ѿ�������С����������Ϊ���ܴ��ڸ��ŵ�·���Ѿ������� dist��
            if (total_distance > dist[current_node][visited_nodes_bitmask])
                continue;

            // ����Ѿ����������нڵ㣬��������
            //-1��ʾ֮ǰ���
            if (visited_nodes_bitmask == (1 << N) - 1)
            {
                break;
            }

            // ������ǰ�ڵ�������ھ�
            for (int neighbor = 0; neighbor < N; ++neighbor)
            {
                // ������ڱ�
                if (_matrix[current_node][neighbor] != INT_MAX)
                {
                    // �����µ��ܾ���
                    W new_total_distance = total_distance + _matrix[current_node][neighbor];

                    // �����ѷ��ʽڵ��λ����
                    int new_visited_nodes_bitmask = visited_nodes_bitmask | (1 << neighbor);

                    // ����ҵ���һ�����̵�·�������¾���͸��ڵ���Ϣ
                    if (new_total_distance < dist[neighbor][new_visited_nodes_bitmask])
                    {
                        dist[neighbor][new_visited_nodes_bitmask] = new_total_distance;
                        parent[neighbor][new_visited_nodes_bitmask] = { current_node, visited_nodes_bitmask };

                        // ���µ�״̬�������ȶ���
                        pq.push({ new_total_distance, neighbor, new_visited_nodes_bitmask });
                    }
                }
            }
        }

        // Ѱ�ҷ������нڵ������ܾ���Ͷ�Ӧ�Ľ����ڵ�
        W min_total_distance = INT_MAX;
        int ending_node = -1;
        for (int node = 0; node < N; ++node)
        {
            if (dist[node][(1 << N) - 1] < min_total_distance)
            {
                min_total_distance = dist[node][(1 << N) - 1];
                ending_node = node;
            }
        }

        // ���û���ҵ�·��������
        if (ending_node == -1)
        {
            std::cout << "No path found to visit all nodes." << std::endl;
            return INT_MAX;
        }

        // �ؽ�·��
        std::vector<int> path;
        int current_node = ending_node;
        int visited_nodes_bitmask = (1 << N) - 1;

        while (current_node != -1)
        {
            path.push_back(current_node);
            auto [prev_node, prev_bitmask] = parent[current_node][visited_nodes_bitmask];
            current_node = prev_node;
            visited_nodes_bitmask = prev_bitmask;
        }

        // �����Ǵ��յ���ݵ���㣬��Ҫ��ת·��
        std::reverse(path.begin(), path.end());

        // ��ӡ·��
        std::cout << "Shortest path visiting all nodes starting from " << src << ":\n";
        for (size_t i = 0; i < path.size(); ++i)
        {
            std::cout << _vertex[path[i]];
            if (i != path.size() - 1)
                std::cout << " -> ";
        }
        std::cout << std::endl;
        std::cout << "totalPath: " << min_total_distance << std::endl;
        return min_total_distance;
    }



    

private:
    void _DFS(int srci, std::vector<bool>& visited)
    {
        std::cout << srci << _vertex[srci] << " ";
        visited[srci] = true;
        for (int i = 0; i < _vertex.size(); i++)
        {
            if (visited[i] == false && _matrix[srci][i] != INT_MAX)
            {
                _DFS(i, visited);
            }
        }
    }
    // std::vector<std::pair<V,int>> _vIndex;
    std::unordered_map<V, int> _vIndex;  // �±�����
    std::vector<V> _vertex;              // ����
    std::vector<std::vector<W>> _matrix; // ����洢
};
